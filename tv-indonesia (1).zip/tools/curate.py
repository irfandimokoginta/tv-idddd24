"""
Menyusun playlist channel Indonesia yang hanya memakai server resmi stasiun TV
(atau penyedia hosting yang dipakai stasiun lokal), dari beberapa playlist publik.
Restream channel komersial dari server pihak ketiga sengaja tidak dimasukkan.

Pemakaian: python3 curate.py iptv-org-id.m3u mgi24-idwork.m3u free-tv.m3u8 > indonesia.m3u
"""
import re, sys
from urllib.parse import urlparse

def parse(path):
    out, cur, opts = [], None, []
    for line in open(path, encoding='utf-8', errors='replace'):
        line = line.strip()
        if line.startswith('#EXTINF'):
            attrs = dict((k.lower(), v) for k, v in re.findall(r'([\w-]+)="([^"]*)"', line))
            s = re.sub(r'[\w-]+="[^"]*"', '', line)
            cur, opts = {'name': s[s.find(',') + 1:].strip(), 'logo': attrs.get('tvg-logo', ''),
                         'tvg_id': attrs.get('tvg-id', ''), 'group': attrs.get('group-title', ''),
                         'country': attrs.get('tvg-country', '')}, []
        elif line.startswith('#EXTVLCOPT'):
            opts.append(line)
        elif line and not line.startswith('#') and cur:
            cur['url'], cur['opts'] = line, opts
            out.append(cur)
            cur = None
    return out

REGION = {
    'north sulawesi': 'Sulawesi Utara', 'north sumatra': 'Sumatera Utara', 'west papua': 'Papua Barat',
    'dki jakarta': 'Jakarta', 'jakarta': 'Jakarta',
}

def clean(name):
    not247 = '[Not 24/7]' in name
    n = re.sub(r'\[[^\]]*\]', '', name)
    n = re.sub(r'\((\d{3,4}[pi])\)', '', n)
    n = re.sub(r'^\(ID\)\s*', '', n, flags=re.I)
    n = re.sub(r'^BACKUP\s+', '', n, flags=re.I)
    n = re.sub(r'\bHD\b', '', n)
    n = re.sub(r'\s+', ' ', n).strip()
    if n.isupper() and n.startswith('TVRI '):
        n = 'TVRI ' + n[5:].title()
    if n.isupper() and n in ('CNN INDONESIA', 'METRO TV'):
        n = {'CNN INDONESIA': 'CNN Indonesia', 'METRO TV': 'Metro TV'}[n]
    if n.lower() == 'yogyakarta':
        n = 'TVRI Yogyakarta'
    m = re.match(r'(?i)^tvri\s+(.*)$', n)
    if m:
        reg = m.group(1).strip()
        n = 'TVRI ' + REGION.get(reg.lower(), reg)
    if n.lower() in ('tvri', 'tvri nasional'):
        n = 'TVRI Nasional'
    if n.lower() == 'tvri olahraga':
        n = 'TVRI Sport'
    return n, not247

# Host -> kategori. Hanya host di daftar ini yang dipakai.
NATIONAL = ['tvri.go.id', 'tvri.co.id', 'rri.go.id', 'dpr.go.id', 'rtv.co.id', 'daaiplus.com', 'tvstreamcast.com']
NEWS = ['medcom.id', 'metrotvnews.com', 'cnnindonesia.com', 'cnbcindonesia.com', 'video.detik.com',
        'beritasatumedia.com', 'bpmedialive.com']
RELIGI = ['rodjatv.com', 'rodja.live', 'aliman.id', 'salamtelevisi.com', 'naajiyatv.com']
EDU = ['gunadarma.ac.id', 'tvku.tv']
LOCAL = ['siar.us', 'streamlock.net', '122.248.43.242', '122.248.43.138', 'staratv.id', 'jogjatv.co.id',
         'efarinatv.com', 'salira.tv', 'carubantv.id', 'matrixtv.id', 'rbtvjogja.tv', 'rinjanitv.cloud',
         'globaldigitalcore.com', 'u-channel.tv', 'radartv.co.id', 'juraganstreaming.com', 'lingkartv.my.id',
         'indonusa.id', 'convergen.co', 'asianastream.com', 'maxindo.net.id', 'tvmu', 'klikhost.com']

def host_match(host, lst):
    return any(host == d or host.endswith('.' + d) or host.startswith(d) for d in lst)

def category(name, host):
    if name.startswith('TVRI ') and name not in ('TVRI Nasional', 'TVRI Sport', 'TVRI World'):
        return 'TVRI Daerah'
    if host_match(host, NEWS) or name in ('Metro TV', 'CNN Indonesia', 'CNBC Indonesia', 'BeritaSatu', 'IDTV'):
        if name == 'Magna Channel':
            return 'Nasional'
        return 'Berita'
    if host_match(host, NATIONAL):
        return 'Edukasi' if 'Indonesiana' in name else 'Nasional'
    if host_match(host, RELIGI):
        return 'Religi'
    if host_match(host, EDU):
        return 'Edukasi'
    if host_match(host, LOCAL):
        return 'TV Lokal'
    return None

ORDER = ['Nasional', 'Berita', 'TVRI Daerah', 'Religi', 'Edukasi', 'TV Lokal']
PIN = ['TVRI Nasional', 'TVRI Sport', 'TVRI World', 'RRI Net', 'TVRI Sulawesi Utara', 'Kawanua TV', 'Celebes TV']

chans = {}
def is_indonesian(e):
    tid = e['tvg_id'].split('@')[0].lower()
    return e['group'] == 'Indonesia' or e['country'].upper() == 'ID' or tid.endswith('.id')

# Dua file pertama khusus Indonesia; file berikutnya (playlist dunia) disaring per channel.
for i, path in enumerate(sys.argv[1:]):
    for e in parse(path):
        if i >= 2 and not is_indonesian(e):
            continue
        if 'balikapan' in e['name'].lower():
            continue
        host = urlparse(e['url']).netloc.split(':')[0].lower()
        name, not247 = clean(e['name'])
        cat = category(name, host)
        if not cat:
            continue
        key = re.sub(r'[^a-z0-9]', '', name.lower())
        c = chans.setdefault(key, {'name': name, 'cat': cat, 'logo': '', 'tvg_id': '', 'not247': not247, 'streams': []})
        if not c['logo'] and e['logo'].startswith('http'):
            c['logo'] = e['logo']
        if not c['tvg_id']:
            c['tvg_id'] = e['tvg_id']
        if e['url'] not in [s['url'] for s in c['streams']]:
            c['streams'].append({'url': e['url'], 'opts': e['opts']})

def sort_key(c):
    pin = PIN.index(c['name']) if c['name'] in PIN else len(PIN)
    return (ORDER.index(c['cat']), pin, c['name'].lower())

print('#EXTM3U')
print('# Playlist TV Indonesia — hanya server resmi stasiun / hosting stasiun lokal.')
print('# Baris dengan nama sama = cadangan; aplikasi mencoba berurutan.')
for c in sorted(chans.values(), key=sort_key):
    # utamakan https di depan
    streams = sorted(c['streams'], key=lambda s: (1 if s['opts'] else 0, 0 if s['url'].startswith('https') else 1))
    label = c['name'] + (' (tidak 24 jam)' if c['not247'] else '')
    for s in streams:
        attrs = []
        if c['tvg_id']: attrs.append('tvg-id="%s"' % c['tvg_id'])
        if c['logo']: attrs.append('tvg-logo="%s"' % c['logo'])
        attrs.append('group-title="%s"' % c['cat'])
        print('#EXTINF:-1 %s,%s' % (' '.join(attrs), label))
        for o in s['opts']:
            print(o)
        print(s['url'])
